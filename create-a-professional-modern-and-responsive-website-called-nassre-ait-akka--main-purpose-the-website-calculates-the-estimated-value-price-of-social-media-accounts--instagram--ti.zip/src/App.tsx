import { useState, useEffect, useCallback } from 'react';

// ==================== TYPES ====================
interface CalculationResult {
  engagementRate: number;
  basePrice: number;
  adjustedPrice: number;
  priceUSD: number;
  priceMAD: number;
  quality: 'low' | 'medium' | 'high';
  qualityText: string;
  trustScore: number;
}

type Platform = 'instagram' | 'tiktok' | 'youtube';
type Language = 'ar' | 'fr';

// ==================== TRANSLATIONS ====================
const translations = {
  ar: {
    // Header
    title: 'نسر آيت عكة',
    subtitle: 'احسب قيمة حسابك على وسائل التواصل الاجتماعي',
    
    // Form
    platformLabel: 'اختر المنصة',
    instagram: 'إنستغرام',
    tiktok: 'تيك توك',
    youtube: 'يوتيوب',
    usernameLabel: 'اسم المستخدم أو رابط الحساب',
    usernamePlaceholder: '@username أو https://...',
    followersLabel: 'عدد المتابعين',
    followersPlaceholder: 'مثال: 8000',
    likesLabel: 'متوسط الإعجابات لكل منشور',
    likesPlaceholder: 'مثال: 500',
    commentsLabel: 'متوسط التعليقات لكل منشور',
    commentsPlaceholder: 'مثال: 50',
    calculateButton: 'احسب القيمة',
    calculating: 'جاري الحساب...',
    
    // Results
    resultsTitle: 'نتائج التقييم',
    estimatedValue: 'القيمة المقدرة',
    engagementRate: 'معدل التفاعل',
    accountQuality: 'جودة الحساب',
    trustScore: 'درجة الثقة',
    qualityLow: 'منخفض',
    qualityMedium: 'متوسط',
    qualityHigh: 'عالي',
    saveResult: 'حفظ النتيجة',
    newCalculation: 'حساب جديد',
    
    // How it works
    howItWorksTitle: 'كيف يعمل؟',
    step1Title: 'أدخل بياناتك',
    step1Desc: 'أدخل عدد المتابعين ومتوسط الإعجابات والتعليقات',
    step2Title: 'اختر المنصة',
    step2Desc: 'اختر إنستغرام أو تيك توك أو يوتيوب',
    step3Title: 'احصل على النتيجة',
    step3Desc: 'نحسب لك القيمة المقدرة بدقة عالية',
    
    // Footer
    footerText: '© 2024 نسر آيت عكة - جميع الحقوق محفوظة',
    disclaimer: 'الأرقام تقديرية وتعتمد على معادلات رياضية',
    
    // Errors
    errorFollowers: 'يرجى إدخال عدد المتابعين',
    errorLikes: 'يرجى إدخال متوسط الإعجابات',
    errorComments: 'يرجى إدخال متوسط التعليقات',
    errorInvalid: 'القيم غير صالحة',
    
    // Saved
    lastResult: 'آخر نتيجة محفوظة',
    noSavedResult: 'لا توجد نتيجة محفوظة',
  },
  fr: {
    // Header
    title: 'Nassre Ait Akka',
    subtitle: 'Estimez la valeur de vos comptes sur les réseaux sociaux',
    
    // Form
    platformLabel: 'Choisir la plateforme',
    instagram: 'Instagram',
    tiktok: 'TikTok',
    youtube: 'YouTube',
    usernameLabel: 'Nom d\'utilisateur ou lien du profil',
    usernamePlaceholder: '@username ou https://...',
    followersLabel: 'Nombre d\'abonnés',
    followersPlaceholder: 'Ex: 8000',
    likesLabel: 'Moyenne de likes par publication',
    likesPlaceholder: 'Ex: 500',
    commentsLabel: 'Moyenne de commentaires par publication',
    commentsPlaceholder: 'Ex: 50',
    calculateButton: 'Calculer la valeur',
    calculating: 'Calcul en cours...',
    
    // Results
    resultsTitle: 'Résultats de l\'évaluation',
    estimatedValue: 'Valeur estimée',
    engagementRate: 'Taux d\'engagement',
    accountQuality: 'Qualité du compte',
    trustScore: 'Score de confiance',
    qualityLow: 'Faible',
    qualityMedium: 'Moyen',
    qualityHigh: 'Élevé',
    saveResult: 'Sauvegarder',
    newCalculation: 'Nouveau calcul',
    
    // How it works
    howItWorksTitle: 'Comment ça marche ?',
    step1Title: 'Entrez vos données',
    step1Desc: 'Entrez vos abonnés, likes et commentaires moyens',
    step2Title: 'Choisissez la plateforme',
    step2Desc: 'Sélectionnez Instagram, TikTok ou YouTube',
    step3Title: 'Obtenez le résultat',
    step3Desc: 'Nous calculons la valeur estimée avec précision',
    
    // Footer
    footerText: '© 2024 Nassre Ait Akka - Tous droits réservés',
    disclaimer: 'Les chiffres sont estimatifs basés sur des formules mathématiques',
    
    // Errors
    errorFollowers: 'Veuillez entrer le nombre d\'abonnés',
    errorLikes: 'Veuillez entrer la moyenne de likes',
    errorComments: 'Veuillez entrer la moyenne de commentaires',
    errorInvalid: 'Valeurs invalides',
    
    // Saved
    lastResult: 'Dernier résultat sauvegardé',
    noSavedResult: 'Aucun résultat sauvegardé',
  }
};

// ==================== PLATFORM FACTORS ====================
const platformFactors: Record<Platform, number> = {
  instagram: 0.02,
  tiktok: 0.015,
  youtube: 0.03
};

// ==================== MAIN APP COMPONENT ====================
export default function App() {
  // State
  const [language, setLanguage] = useState<Language>('ar');
  const [platform, setPlatform] = useState<Platform>('instagram');
  const [username, setUsername] = useState('');
  const [followers, setFollowers] = useState<string>('');
  const [likes, setLikes] = useState<string>('');
  const [comments, setComments] = useState<string>('');
  const [isCalculating, setIsCalculating] = useState(false);
  const [result, setResult] = useState<CalculationResult | null>(null);
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [savedResult, setSavedResult] = useState<CalculationResult | null>(null);
  const [showSaved, setShowSaved] = useState(false);

  const t = translations[language];
  const isRTL = language === 'ar';

  // Load saved result from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem('nassre_last_result');
    if (saved) {
      try {
        setSavedResult(JSON.parse(saved));
      } catch (e) {
        console.error('Error loading saved result:', e);
      }
    }
  }, []);

  // ==================== CALCULATION FUNCTION ====================
  const calculateValue = useCallback((): CalculationResult | null => {
    const followersNum = parseInt(followers) || 0;
    const likesNum = parseInt(likes) || 0;
    const commentsNum = parseInt(comments) || 0;

    // Validate inputs
    if (followersNum <= 0 || likesNum < 0 || commentsNum < 0) {
      return null;
    }

    // Calculate engagement rate
    const engagementRate = ((likesNum + commentsNum) / followersNum) * 100;

    // Get platform factor
    const factor = platformFactors[platform];

    // Base price calculation
    const basePrice = followersNum * (engagementRate / 100) * factor * 10;

    // Smart adjustments
    let adjustedPrice = basePrice;
    if (engagementRate > 5) {
      adjustedPrice = basePrice * 1.5; // +50% for high engagement
    } else if (engagementRate < 2) {
      adjustedPrice = basePrice * 0.7; // -30% for low engagement
    }

    // Determine quality
    let quality: 'low' | 'medium' | 'high';
    let qualityText: string;
    if (engagementRate >= 5) {
      quality = 'high';
      qualityText = t.qualityHigh;
    } else if (engagementRate >= 2) {
      quality = 'medium';
      qualityText = t.qualityMedium;
    } else {
      quality = 'low';
      qualityText = t.qualityLow;
    }

    // Calculate trust score (based on data consistency)
    const trustScore = Math.min(100, Math.round(
      50 + // Base score
      (engagementRate > 0.5 && engagementRate < 15 ? 20 : 0) + // Reasonable engagement
      (followersNum > 100 ? 15 : 0) + // Minimum followers
      (likesNum > 0 ? 15 : 0) // Has likes
    ));

    // Final prices
    const priceUSD = Math.round(adjustedPrice * 100) / 100;
    const priceMAD = Math.round(priceUSD * 10);

    return {
      engagementRate: Math.round(engagementRate * 100) / 100,
      basePrice: Math.round(basePrice * 100) / 100,
      adjustedPrice: Math.round(adjustedPrice * 100) / 100,
      priceUSD,
      priceMAD,
      quality,
      qualityText,
      trustScore
    };
  }, [followers, likes, comments, platform, t.qualityHigh, t.qualityMedium, t.qualityLow]);

  // ==================== FORM VALIDATION ====================
  const validateForm = (): boolean => {
    const newErrors: { [key: string]: string } = {};

    if (!followers || parseInt(followers) <= 0) {
      newErrors.followers = t.errorFollowers;
    }
    if (!likes || parseInt(likes) < 0) {
      newErrors.likes = t.errorLikes;
    }
    if (!comments || parseInt(comments) < 0) {
      newErrors.comments = t.errorComments;
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  // ==================== HANDLE CALCULATE ====================
  const handleCalculate = async () => {
    if (!validateForm()) return;

    setIsCalculating(true);
    setResult(null);

    // Simulate AI processing delay
    await new Promise(resolve => setTimeout(resolve, 1500));

    const calculatedResult = calculateValue();
    if (calculatedResult) {
      setResult(calculatedResult);
    }

    setIsCalculating(false);
  };

  // ==================== SAVE RESULT ====================
  const handleSaveResult = () => {
    if (result) {
      localStorage.setItem('nassre_last_result', JSON.stringify(result));
      setSavedResult(result);
      setShowSaved(true);
      setTimeout(() => setShowSaved(false), 2000);
    }
  };

  // ==================== RESET FORM ====================
  const handleReset = () => {
    setUsername('');
    setFollowers('');
    setLikes('');
    setComments('');
    setResult(null);
    setErrors({});
  };

  // ==================== PLATFORM ICONS ====================
  const PlatformIcon = ({ type, size = 24 }: { type: Platform; size?: number }) => {
    if (type === 'instagram') {
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
        </svg>
      );
    }
    if (type === 'tiktok') {
      return (
        <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
          <path d="M19.59 6.69a4.83 4.83 0 0 1-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 0 1-5.2 1.74 2.89 2.89 0 0 1 2.31-4.64 2.93 2.93 0 0 1 .88.13V9.4a6.84 6.84 0 0 0-1-.05A6.33 6.33 0 0 0 5 20.1a6.34 6.34 0 0 0 10.86-4.43v-7a8.16 8.16 0 0 0 4.77 1.52v-3.4a4.85 4.85 0 0 1-1-.1z"/>
        </svg>
      );
    }
    return (
      <svg width={size} height={size} viewBox="0 0 24 24" fill="currentColor">
        <path d="M23.498 6.186a3.016 3.016 0 0 0-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 0 0 .502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 0 0 2.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 0 0 2.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/>
      </svg>
    );
  };

  // ==================== QUALITY BADGE COLOR ====================
  const getQualityColor = (quality: string) => {
    switch (quality) {
      case 'high': return 'from-green-500 to-emerald-500';
      case 'medium': return 'from-yellow-500 to-orange-500';
      default: return 'from-red-500 to-rose-500';
    }
  };

  // ==================== RENDER ====================
  return (
    <div 
      className={`min-h-screen bg-gradient-main text-white ${isRTL ? 'rtl' : 'ltr'}`}
      dir={isRTL ? 'rtl' : 'ltr'}
    >
      {/* ==================== HEADER ==================== */}
      <header className="sticky top-0 z-50 glass">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-gradient-button flex items-center justify-center animate-pulse-glow">
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
                </svg>
              </div>
              <div>
                <h1 className="text-xl font-bold text-gradient">{t.title}</h1>
                <p className="text-xs text-gray-400 hidden sm:block">{t.subtitle}</p>
              </div>
            </div>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'ar' ? 'fr' : 'ar')}
              className="flex items-center gap-2 px-4 py-2 rounded-xl glass hover:bg-white/10 transition-all"
            >
              <span className="text-lg">{language === 'ar' ? '🇫🇷' : '🇸🇦'}</span>
              <span className="text-sm font-medium">{language === 'ar' ? 'FR' : 'العربية'}</span>
            </button>
          </div>
        </div>
      </header>

      {/* ==================== MAIN CONTENT ==================== */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <section className="text-center mb-12 animate-fade-in">
          <h2 className="text-3xl md:text-5xl font-bold mb-4">
            <span className="text-gradient">{isRTL ? 'احسب قيمة حسابك' : 'Calculez la valeur'}</span>
            <br />
            <span className="text-white">{isRTL ? 'على وسائل التواصل الاجتماعي' : 'de votre compte social'}</span>
          </h2>
          <p className="text-gray-400 max-w-2xl mx-auto">
            {isRTL 
              ? 'أداة ذكية لتقدير قيمة حساباتك على إنستغرام وتيك توك ويوتيوب بناءً على التفاعل والمتابعين'
              : 'Outil intelligent pour estimer la valeur de vos comptes Instagram, TikTok et YouTube basé sur l\'engagement et les abonnés'
            }
          </p>
        </section>

        {/* Calculator Card */}
        <section className="max-w-2xl mx-auto mb-16">
          <div className="bg-gradient-card rounded-3xl p-6 md:p-8 neon-border animate-fade-in">
            {/* Platform Selection */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-3">
                {t.platformLabel}
              </label>
              <div className="grid grid-cols-3 gap-3">
                {(['instagram', 'tiktok', 'youtube'] as Platform[]).map((p) => (
                  <button
                    key={p}
                    onClick={() => setPlatform(p)}
                    className={`flex flex-col items-center gap-2 p-4 rounded-2xl transition-all ${
                      platform === p 
                        ? 'bg-gradient-button shadow-lg shadow-purple-500/30 scale-105' 
                        : 'glass hover:bg-white/10'
                    }`}
                  >
                    <PlatformIcon type={p} size={28} />
                    <span className="text-sm font-medium">
                      {t[p]}
                    </span>
                  </button>
                ))}
              </div>
            </div>

            {/* Username Input */}
            <div className="mb-6">
              <label className="block text-sm font-medium text-gray-300 mb-2">
                {t.usernameLabel}
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t.usernamePlaceholder}
                className="w-full px-4 py-3 rounded-xl bg-black/30 border border-purple-500/30 focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all placeholder-gray-500"
              />
            </div>

            {/* Stats Inputs */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              {/* Followers */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {t.followersLabel} *
                </label>
                <input
                  type="number"
                  value={followers}
                  onChange={(e) => setFollowers(e.target.value)}
                  placeholder={t.followersPlaceholder}
                  className={`w-full px-4 py-3 rounded-xl bg-black/30 border ${
                    errors.followers ? 'border-red-500' : 'border-purple-500/30'
                  } focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all placeholder-gray-500`}
                />
                {errors.followers && (
                  <p className="text-red-400 text-xs mt-1">{errors.followers}</p>
                )}
              </div>

              {/* Likes */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {t.likesLabel} *
                </label>
                <input
                  type="number"
                  value={likes}
                  onChange={(e) => setLikes(e.target.value)}
                  placeholder={t.likesPlaceholder}
                  className={`w-full px-4 py-3 rounded-xl bg-black/30 border ${
                    errors.likes ? 'border-red-500' : 'border-purple-500/30'
                  } focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all placeholder-gray-500`}
                />
                {errors.likes && (
                  <p className="text-red-400 text-xs mt-1">{errors.likes}</p>
                )}
              </div>

              {/* Comments */}
              <div>
                <label className="block text-sm font-medium text-gray-300 mb-2">
                  {t.commentsLabel} *
                </label>
                <input
                  type="number"
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  placeholder={t.commentsPlaceholder}
                  className={`w-full px-4 py-3 rounded-xl bg-black/30 border ${
                    errors.comments ? 'border-red-500' : 'border-purple-500/30'
                  } focus:border-purple-500 focus:ring-2 focus:ring-purple-500/20 outline-none transition-all placeholder-gray-500`}
                />
                {errors.comments && (
                  <p className="text-red-400 text-xs mt-1">{errors.comments}</p>
                )}
              </div>
            </div>

            {/* Calculate Button */}
            <button
              onClick={handleCalculate}
              disabled={isCalculating}
              className="w-full py-4 rounded-xl bg-gradient-button font-bold text-lg transition-all hover:shadow-lg hover:shadow-purple-500/30 hover:scale-[1.02] disabled:opacity-70 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              {isCalculating ? (
                <>
                  <div className="spinner animate-spin-slow"></div>
                  <span>{t.calculating}</span>
                </>
              ) : (
                <>
                  <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
                  </svg>
                  <span>{t.calculateButton}</span>
                </>
              )}
            </button>
          </div>
        </section>

        {/* Results Section */}
        {result && (
          <section className="max-w-2xl mx-auto mb-16 animate-fade-in">
            <div className="bg-gradient-card rounded-3xl p-6 md:p-8 neon-border">
              <h3 className="text-2xl font-bold text-center mb-8 text-gradient">
                {t.resultsTitle}
              </h3>

              {/* Main Value Display */}
              <div className="text-center mb-8 p-6 rounded-2xl bg-black/30">
                <p className="text-gray-400 mb-2">{t.estimatedValue}</p>
                <div className="animate-counting">
                  <p className="text-4xl md:text-5xl font-bold text-gradient mb-2">
                    ${result.priceUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-xl text-gray-300">
                    {result.priceMAD.toLocaleString('en-US')} MAD
                  </p>
                </div>
              </div>

              {/* Stats Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                {/* Engagement Rate */}
                <div className="p-4 rounded-2xl bg-black/30 text-center">
                  <p className="text-gray-400 text-sm mb-1">{t.engagementRate}</p>
                  <p className="text-2xl font-bold text-blue-400">
                    {result.engagementRate}%
                  </p>
                </div>

                {/* Quality */}
                <div className="p-4 rounded-2xl bg-black/30 text-center">
                  <p className="text-gray-400 text-sm mb-1">{t.accountQuality}</p>
                  <span className={`inline-block px-4 py-1 rounded-full bg-gradient-to-r ${getQualityColor(result.quality)} text-white font-bold`}>
                    {result.qualityText}
                  </span>
                </div>

                {/* Trust Score */}
                <div className="p-4 rounded-2xl bg-black/30 text-center">
                  <p className="text-gray-400 text-sm mb-1">{t.trustScore}</p>
                  <div className="flex items-center justify-center gap-2">
                    <div className="w-full max-w-[100px] h-2 bg-gray-700 rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-gradient-button rounded-full transition-all duration-500"
                        style={{ width: `${result.trustScore}%` }}
                      />
                    </div>
                    <span className="text-lg font-bold text-purple-400">{result.trustScore}%</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleSaveResult}
                  className="flex-1 py-3 px-6 rounded-xl glass hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  {showSaved ? (
                    <>
                      <svg className="w-5 h-5 text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                      <span className="text-green-400">{isRTL ? 'تم الحفظ!' : 'Sauvegardé!'}</span>
                    </>
                  ) : (
                    <>
                      <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
                      </svg>
                      <span>{t.saveResult}</span>
                    </>
                  )}
                </button>
                <button
                  onClick={handleReset}
                  className="flex-1 py-3 px-6 rounded-xl glass hover:bg-white/10 transition-all flex items-center justify-center gap-2"
                >
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                  </svg>
                  <span>{t.newCalculation}</span>
                </button>
              </div>
            </div>
          </section>
        )}

        {/* Saved Result Display */}
        {savedResult && !result && (
          <section className="max-w-2xl mx-auto mb-16 animate-fade-in">
            <div className="bg-gradient-card rounded-2xl p-4 glass">
              <p className="text-sm text-gray-400 mb-2">{t.lastResult}</p>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xl font-bold text-gradient">
                    ${savedResult.priceUSD.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </p>
                  <p className="text-sm text-gray-400">{savedResult.priceMAD.toLocaleString('en-US')} MAD</p>
                </div>
                <span className={`px-3 py-1 rounded-full bg-gradient-to-r ${getQualityColor(savedResult.quality)} text-white text-sm`}>
                  {savedResult.qualityText}
                </span>
              </div>
            </div>
          </section>
        )}

        {/* How It Works Section */}
        <section className="max-w-4xl mx-auto mb-16">
          <h3 className="text-2xl md:text-3xl font-bold text-center mb-10 text-gradient">
            {t.howItWorksTitle}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-gradient-card rounded-2xl p-6 text-center neon-border animate-bounce-subtle" style={{ animationDelay: '0s' }}>
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-button flex items-center justify-center text-2xl font-bold">
                1
              </div>
              <h4 className="text-lg font-bold mb-2">{t.step1Title}</h4>
              <p className="text-gray-400 text-sm">{t.step1Desc}</p>
            </div>

            {/* Step 2 */}
            <div className="bg-gradient-card rounded-2xl p-6 text-center neon-border animate-bounce-subtle" style={{ animationDelay: '0.2s' }}>
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-button flex items-center justify-center text-2xl font-bold">
                2
              </div>
              <h4 className="text-lg font-bold mb-2">{t.step2Title}</h4>
              <p className="text-gray-400 text-sm">{t.step2Desc}</p>
            </div>

            {/* Step 3 */}
            <div className="bg-gradient-card rounded-2xl p-6 text-center neon-border animate-bounce-subtle" style={{ animationDelay: '0.4s' }}>
              <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-gradient-button flex items-center justify-center text-2xl font-bold">
                3
              </div>
              <h4 className="text-lg font-bold mb-2">{t.step3Title}</h4>
              <p className="text-gray-400 text-sm">{t.step3Desc}</p>
            </div>
          </div>
        </section>

        {/* Formula Explanation */}
        <section className="max-w-2xl mx-auto mb-16">
          <div className="bg-gradient-card rounded-2xl p-6 neon-border">
            <h4 className="text-lg font-bold mb-4 text-center text-gradient">
              {isRTL ? 'كيف نحسب القيمة؟' : 'Comment calculons-nous la valeur?'}
            </h4>
            <div className="space-y-3 text-sm text-gray-300">
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/30">
                <span className="text-purple-400 font-mono">1.</span>
                <span>{isRTL ? 'معدل التفاعل = (الإعجابات + التعليقات) ÷ المتابعين × 100' : 'Taux d\'engagement = (Likes + Commentaires) ÷ Abonnés × 100'}</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/30">
                <span className="text-purple-400 font-mono">2.</span>
                <span>{isRTL ? 'السعر الأساسي = المتابعين × معدل التفاعل × معامل المنصة × 10' : 'Prix de base = Abonnés × Taux × Facteur × 10'}</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/30">
                <span className="text-purple-400 font-mono">3.</span>
                <span>{isRTL ? 'معاملات المنصة: إنستغرام 0.02 | تيك توك 0.015 | يوتيوب 0.03' : 'Facteurs: Instagram 0.02 | TikTok 0.015 | YouTube 0.03'}</span>
              </div>
              <div className="flex items-center gap-3 p-3 rounded-xl bg-black/30">
                <span className="text-purple-400 font-mono">4.</span>
                <span>{isRTL ? 'إذا التفاعل > 5% → السعر يزيد 50% | إذا < 2% → ينقص 30%' : 'Si engagement > 5% → Prix +50% | Si < 2% → Prix -30%'}</span>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* ==================== FOOTER ==================== */}
      <footer className="glass mt-auto">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center">
            <p className="text-gray-400 mb-2">{t.footerText}</p>
            <p className="text-xs text-gray-500">{t.disclaimer}</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
